#include "HostAddressProvider.h"

#include <array>
#include <fstream>
#include <random>
#include <sstream>
#include <iomanip>

HostAddressProvider::HostAddressProvider(MODE mode, unsigned short roomNumber, ENetHost* enetHost, enet_uint16 localPort) :
	mode(mode),
	state(STATE::Initialize),

	roomNumber(roomNumber),

	machineId(),

	enetHost(enetHost),

	controlSocket(-1),

	localEndpoint(),
	publicEndpoint(),

	hostMachineId(),
	hostLocalEndpoint(),
	hostPublicEndpoint(),

	connectEndpoint(),
	connectionRoute(CONNECTION_ROUTE::None),

	serverSendCounter(0),
	punchSendCounter(0),
	punchCount(0)
{
	// ENetHost�`�F�b�N
	if (this->enetHost == nullptr) { state = STATE::Error; return; }

	// Machine ID�擾
	machineId = GetOrCreateMachineId();

	if (machineId.empty()) { state = STATE::Error; return; }

	// LAN��IPv4�擾
	localEndpoint.ip = GetLocalIPv4();

	if (localEndpoint.ip.empty()) { state = STATE::Error; return; }

	// NetWorkManager���Ŏ擾����
	// ENet���g�̃|�[�g�ԍ�
	localEndpoint.port = localPort;

	if (localEndpoint.port == 0) {
		state = STATE::Error;
		return;
	}

	// Oracle����ʐM�pUDP�\�P�b�g
	// 0 = OS�ɋ󂫃|�[�g��I�΂���
	controlSocket = MakeUDPSocket(0);

	if (controlSocket == -1) { state = STATE::Error; return; }

	// ����������
	state = STATE::Register;
}


//==============================================================
// �X�V
//==============================================================
void HostAddressProvider::Update(void)
{
	if (state == STATE::Complete || state == STATE::Error) { return; }

	// Oracle����̃��b�Z�[�W�𖈃t���[���m�F
	ReceiveServerMessage();

	// MODE�ʍX�V
	switch (mode) {

	case MODE::Host:
		HostUpdate();
		break;

	case MODE::Client:
		ClientUpdate();
		break;

	default:
		state = STATE::Error;
		break;
	}
}


//==============================================================
// �I��
//==============================================================
void HostAddressProvider::End(void)
{
	if (controlSocket != -1) {
		DeleteUDPSocket(controlSocket);
		controlSocket = -1;
	}

	// enetHost��NetWorkManager���L�Ȃ̂�
	// �����ł͔j�����Ȃ�
	enetHost = nullptr;
}


//==============================================================
// �ŏI�ڑ���擾
//==============================================================
bool HostAddressProvider::GetConnectEndpoint(
	NetEndpoint& endpoint,
	CONNECTION_ROUTE& route
) const
{
	if (state != STATE::Complete) {
		return false;
	}

	if (!connectEndpoint.IsValid()) {
		return false;
	}

	endpoint = connectEndpoint;
	route = connectionRoute;

	return true;
}


//==============================================================
// �z�X�g�X�V
//==============================================================
void HostAddressProvider::HostUpdate(void)
{
	switch (state) {

		//----------------------------------------------------------
		// Oracle�փz�X�g�o�^
		//----------------------------------------------------------
	case STATE::Register:
	{
		// ���Ԋu�ōđ�����
		if (serverSendCounter <= 0) {

			RegisterToServer();

			// ENet���g�̃\�P�b�g�����Oracle�֑���
			SendEndpointProbe();

			serverSendCounter = SERVER_SEND_COOLTIME;
		}
		else {
			--serverSendCounter;
		}

		break;
	}

	//----------------------------------------------------------
	// HOST�͊�{�I�Ƀ}�b�`���O�҂�
	//----------------------------------------------------------
	case STATE::WaitMatch:
	{
		// KeepAlive���ēo�^
		if (serverSendCounter <= 0) {

			RegisterToServer();

			SendEndpointProbe();

			serverSendCounter = SERVER_SEND_COOLTIME;
		}
		else {
			--serverSendCounter;
		}

		break;
	}

	//----------------------------------------------------------
	// NAT Hole Punch
	//----------------------------------------------------------
	case STATE::Punch:
	{
		if (!hostPublicEndpoint.IsValid()) {
			// HOST���ł͂��̕ϐ���
			// �u�ڑ����Ă���CLIENT��Public Endpoint�v��
			// �ꎞ�I�ɐݒ肳���
			break;
		}

		if (punchSendCounter <= 0) {

			SendPunchPacket(hostPublicEndpoint);

			punchSendCounter = PUNCH_SEND_COOLTIME;

			++punchCount;
		}
		else {
			--punchSendCounter;
		}

		if (punchCount >= PUNCH_MAX_COUNT) {

			//--------------------------------------------------
			// HOST���͐ڑ����connect����킯�ł͂Ȃ����߁A
			// Hole Punch���\����������ʏ�ҋ@�֖߂�
			//--------------------------------------------------
			state = STATE::WaitMatch;

			punchCount = 0;
			punchSendCounter = 0;
		}

		break;
	}

	default:
		break;
	}
}


//==============================================================
// �N���C�A���g�X�V
//==============================================================
void HostAddressProvider::ClientUpdate(void)
{
	switch (state) {

		//----------------------------------------------------------
		// Oracle�֌����v��
		//----------------------------------------------------------
	case STATE::Register:
	{
		if (serverSendCounter <= 0) {

			RegisterToServer();

			//--------------------------------------------------
			// ENet���g��Public Endpoint��Oracle�Ɋϑ�������
			//--------------------------------------------------
			SendEndpointProbe();

			serverSendCounter = SERVER_SEND_COOLTIME;
		}
		else {
			--serverSendCounter;
		}

		break;
	}

	//----------------------------------------------------------
	// �z�X�g���҂�
	//----------------------------------------------------------
	case STATE::WaitMatch:
	{
		//------------------------------------------------------
		// �K�v��񂪂��������ڑ����@����
		//------------------------------------------------------
		if (!hostMachineId.empty() &&
			hostLocalEndpoint.IsValid() &&
			hostPublicEndpoint.IsValid() &&
			publicEndpoint.IsValid())
		{
			DecideConnectionRoute();
		}

		//------------------------------------------------------
		// �܂��Ȃ�Oracle�֍Ė₢���킹
		//------------------------------------------------------
		if (state == STATE::WaitMatch) {

			if (serverSendCounter <= 0) {

				RegisterToServer();

				SendEndpointProbe();

				serverSendCounter = SERVER_SEND_COOLTIME;
			}
			else {
				--serverSendCounter;
			}
		}

		break;
	}

	//----------------------------------------------------------
	// NAT Hole Punch
	//----------------------------------------------------------
	case STATE::Punch:
	{
		if (!hostPublicEndpoint.IsValid()) {
			break;
		}

		if (punchSendCounter <= 0) {

			//--------------------------------------------------
			// ENet���g�̃\�P�b�g����
			// �z�X�g��Public Endpoint��UDP�𑗂�
			//--------------------------------------------------
			SendPunchPacket(hostPublicEndpoint);

			punchSendCounter = PUNCH_SEND_COOLTIME;

			++punchCount;
		}
		else {
			--punchSendCounter;
		}

		//------------------------------------------------------
		// ���񑗂��ENet�ڑ��ֈڂ�
		//
		// 60��S���҂K�v�͂Ȃ��B
		// �ŏ��ɐ��������J����Ώ\���B
		//------------------------------------------------------
		if (punchCount >= 6) {

			connectEndpoint = hostPublicEndpoint;
			connectionRoute = CONNECTION_ROUTE::Public;

			state = STATE::Complete;
		}

		break;
	}

	default:
		break;
	}
}


//==============================================================
// Oracle�֓o�^
//==============================================================
void HostAddressProvider::RegisterToServer(void)
{
	std::ostringstream ss;

	//----------------------------------------------------------
	// HOST
	//
	// HOST <room> <machineId> <privateIp> <gamePort>
	//----------------------------------------------------------
	if (mode == MODE::Host) {

		ss
			<< "HOST "
			<< roomNumber << ' '
			<< machineId << ' '
			<< localEndpoint.ip << ' '
			<< localEndpoint.port;
	}

	//----------------------------------------------------------
	// CLIENT
	//
	// FIND <room> <machineId> <privateIp> <gamePort>
	//----------------------------------------------------------
	else {

		ss
			<< "FIND "
			<< roomNumber << ' '
			<< machineId << ' '
			<< localEndpoint.ip << ' '
			<< localEndpoint.port;
	}

	SendControlMessage(ss.str());
}


//==============================================================
// Oracle�����M
//==============================================================
void HostAddressProvider::ReceiveServerMessage(void)
{
	if (controlSocket == -1) { return; }

	// 1�t���[���ŕ�����M�ł���悤�ɂ���
	for (int receiveCount = 0; receiveCount < 16; receiveCount++) {
		IPDATA senderAddress{};

		int senderPort = 0;

		std::array<char, 1024> buffer{};

		const int recvSize = NetWorkRecvUDP(controlSocket, &senderAddress, &senderPort, buffer.data(), static_cast<int>(buffer.size() - 1), 0);

		if (recvSize < 0) { break; }

		buffer[(static_cast<size_t>(recvSize) < buffer.size()) ? static_cast<size_t>(recvSize) : buffer.size() - 1] = '\0';

		const std::string message(buffer.data());

		std::istringstream ss(message);

		std::string command;

		ss >> command;

		// HOST�o�^����
		if (command == "HOST_OK") {

			if (mode == MODE::Host) { state = STATE::WaitMatch; }

			continue;
		}

		// ������ENet Public Endpoint
		if (command == "PUBLIC") {

			std::string ip;
			unsigned int port = 0;

			ss >> ip >> port;

			if (!ip.empty() && port > 0 && port <= 65535) {
				publicEndpoint.ip = ip;
				publicEndpoint.port = static_cast<enet_uint16>(port);

				if (mode == MODE::Client && state == STATE::Register) { state = STATE::WaitMatch; }
			}

			continue;
		}

		//------------------------------------------------------
		// �z�X�g����
		//
		// FOUND
		// <machineId>
		// <privateIp>
		// <privatePort>
		// <publicIp>
		// <publicPort>
		//------------------------------------------------------
		if (command == "FOUND") {

			std::string machine;
			std::string localIp;
			std::string publicIp;

			unsigned int localPort = 0;
			unsigned int publicPort = 0;

			ss >> machine >> localIp >> localPort >> publicIp >> publicPort;

			if (machine.empty() || localIp.empty() || publicIp.empty() || localPort == 0 || localPort > 65535 || publicPort == 0 || publicPort > 65535) { continue; }

			hostMachineId = machine;

			hostLocalEndpoint.ip = localIp;
			hostLocalEndpoint.port = static_cast<enet_uint16>(localPort);

			hostPublicEndpoint.ip = publicIp;
			hostPublicEndpoint.port = static_cast<enet_uint16>(publicPort);

			if (mode == MODE::Client) { state = STATE::WaitMatch; }

			continue;
		}

		//------------------------------------------------------
		// NAT Hole Punch�J�n�w��
		//
		// PUNCH <ip> <port>
		//------------------------------------------------------
		if (command == "PUNCH") {

			std::string ip;
			unsigned int port = 0;

			ss >> ip >> port;

			if (ip.empty() || port == 0 || port > 65535) { continue; }

			//--------------------------------------------------
			// HOST���̏ꍇ�A
			// hostPublicEndpoint��
			// �uCLIENT��Public Endpoint�v�̈ꎞ�i�[�Ƃ��Ďg��
			//--------------------------------------------------
			if (mode == MODE::Host) {

				hostPublicEndpoint.ip = ip;
				hostPublicEndpoint.port =
					static_cast<enet_uint16>(port);

				punchCount = 0;
				punchSendCounter = 0;

				state = STATE::Punch;
			}

			//--------------------------------------------------
			// CLIENT���̏ꍇ��
			// ��{FOUND�Ŏ擾�ς݂����A
			// Oracle��PUNCH����D�悷��
			//--------------------------------------------------
			else {

				hostPublicEndpoint.ip = ip;
				hostPublicEndpoint.port =
					static_cast<enet_uint16>(port);

				punchCount = 0;
				punchSendCounter = 0;

				state = STATE::Punch;
			}

			continue;
		}

		//------------------------------------------------------
		// �����Ȃ�
		//
		// NOT_FOUND
		//
		// �G���[�ɂ͂����������p������
		//------------------------------------------------------
		if (command == "NOT_FOUND") {
			continue;
		}

		//------------------------------------------------------
		// �����I�G���[
		//------------------------------------------------------
		if (command == "ERROR") {

			state = STATE::Error;

			continue;
		}
	}
}


//==============================================================
// ENet���g��Public Endpoint��Oracle�Ɋϑ�������
//==============================================================
void HostAddressProvider::SendEndpointProbe(void)
{
	if (enetHost == nullptr) { return; }

	NetEndpoint server;

	server.ip = MATCH_SERVER_IP;
	server.port = static_cast<enet_uint16>(MATCH_SERVER_PORT);

	std::ostringstream ss;

	//----------------------------------------------------------
	// PROBE HOST 111 MachineId
	//
	// �܂���
	//
	// PROBE CLIENT 111 MachineId
	//----------------------------------------------------------
	ss << "PROBE " << ((mode == MODE::Host) ? "HOST" : "CLIENT") << ' ' << roomNumber << ' ' << machineId << ' ' << localEndpoint.port;

	SendRawFromENet(server, ss.str());
}


//==============================================================
// NAT Hole Punch packet
//==============================================================
void HostAddressProvider::SendPunchPacket(
	const NetEndpoint& endpoint
)
{
	if (!endpoint.IsValid()) {
		return;
	}

	std::ostringstream ss;

	ss
		<< "PUNCH_PACKET "
		<< roomNumber
		<< ' '
		<< machineId;

	SendRawFromENet(
		endpoint,
		ss.str()
	);
}


//==============================================================
// �ڑ����@����
//==============================================================
void HostAddressProvider::DecideConnectionRoute(void)
{
	//----------------------------------------------------------
	// �@ ����PC
	//----------------------------------------------------------
	if (hostMachineId == machineId) {

		connectEndpoint.ip = "127.0.0.1";
		connectEndpoint.port =
			hostLocalEndpoint.port;

		connectionRoute =
			CONNECTION_ROUTE::Loopback;

		state = STATE::Complete;

		return;
	}

	//----------------------------------------------------------
	// �A �����O���[�o��IP
	//
	// ���ꃋ�[�^�[�z���Ƃ݂Ȃ��A
	// Private IP�֐ڑ�����B
	//----------------------------------------------------------
	if (publicEndpoint.IsValid() &&
		hostPublicEndpoint.IsValid() &&
		publicEndpoint.ip == hostPublicEndpoint.ip)
	{
		connectEndpoint =
			hostLocalEndpoint;

		connectionRoute =
			CONNECTION_ROUTE::Local;

		state = STATE::Complete;

		return;
	}

	//----------------------------------------------------------
	// �B ��LAN
	//
	// Public Endpoint�֒��ڐڑ�����O��
	// UDP Hole Punch���s���B
	//----------------------------------------------------------
	if (hostPublicEndpoint.IsValid()) {

		punchCount = 0;
		punchSendCounter = 0;

		connectionRoute =
			CONNECTION_ROUTE::Public;

		state = STATE::Punch;

		return;
	}

	//----------------------------------------------------------
	// ���s��
	//----------------------------------------------------------
	state = STATE::WaitMatch;
}


//==============================================================
// Machine ID
//==============================================================
std::string HostAddressProvider::GetOrCreateMachineId(void)
{
	//----------------------------------------------------------
	// �����
	//
	// PC�� + Windows�V�X�e���h���C�u��VolumeSerial
	//
	// ������B
	//
	// ����PC�ŋN������exe���m�Ȃ瓯��ɂȂ�B
	//----------------------------------------------------------

	char computerName[MAX_COMPUTERNAME_LENGTH + 1]{};

	DWORD computerNameLength =
		static_cast<DWORD>(
			std::size(computerName)
			);

	if (!GetComputerNameA(
		computerName,
		&computerNameLength))
	{
		return {};
	}

	DWORD volumeSerial = 0;

	if (!GetVolumeInformationA(
		"C:\\",
		nullptr,
		0,
		&volumeSerial,
		nullptr,
		nullptr,
		nullptr,
		0))
	{
		return {};
	}

	std::ostringstream ss;

	ss
		<< computerName
		<< '-'
		<< std::hex
		<< std::uppercase
		<< std::setw(8)
		<< std::setfill('0')
		<< volumeSerial;

	return ss.str();
}


//==============================================================
// LAN��IPv4�擾
//==============================================================
std::string HostAddressProvider::GetLocalIPv4(void)
{
	char hostName[256]{};

	if (gethostname(
		hostName,
		static_cast<int>(sizeof(hostName))) != 0)
	{
		return {};
	}

	addrinfo hints{};

	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_protocol = IPPROTO_UDP;

	addrinfo* result = nullptr;

	if (getaddrinfo(
		hostName,
		nullptr,
		&hints,
		&result) != 0)
	{
		return {};
	}

	std::string selectedAddress;

	for (addrinfo* ptr = result;
		ptr != nullptr;
		ptr = ptr->ai_next)
	{
		if (ptr->ai_family != AF_INET) {
			continue;
		}

		const sockaddr_in* ipv4 =
			reinterpret_cast<const sockaddr_in*>(
				ptr->ai_addr
				);

		char ipBuffer[INET_ADDRSTRLEN]{};

		if (inet_ntop(
			AF_INET,
			&ipv4->sin_addr,
			ipBuffer,
			sizeof(ipBuffer)) == nullptr)
		{
			continue;
		}

		std::string ip(ipBuffer);

		//------------------------------------------------------
		// Loopback�͏��O
		//------------------------------------------------------
		if (ip.rfind("127.", 0) == 0) {
			continue;
		}

		//------------------------------------------------------
		// APIPA�����O
		//------------------------------------------------------
		if (ip.rfind("169.254.", 0) == 0) {
			continue;
		}

		selectedAddress = ip;

		//------------------------------------------------------
		// 192.168 / 10 / 172.16-31 ��D�悵�����̂ŁA
		// �ŏ��̗L��IPv4���̗p
		//------------------------------------------------------
		break;
	}

	freeaddrinfo(result);

	return selectedAddress;
}


//==============================================================
// Oracle���䃁�b�Z�[�W���M
//==============================================================
bool HostAddressProvider::SendControlMessage(
	const std::string& message
)
{
	if (controlSocket == -1) {
		return false;
	}

	if (message.empty()) {
		return false;
	}

	IPDATA serverAddress =
	{
		161,
		33,
		190,
		216
	};

	const int result =
		NetWorkSendUDP(
			controlSocket,
			serverAddress,
			MATCH_SERVER_PORT,
			message.c_str(),
			static_cast<int>(
				message.size() + 1
				)
		);

	return result >= 0;
}


//==============================================================
// ENet���g�̃\�P�b�g����Raw UDP���M
//==============================================================
bool HostAddressProvider::SendRawFromENet(
	const NetEndpoint& endpoint,
	const std::string& message
)
{
	if (enetHost == nullptr) {
		return false;
	}

	if (!endpoint.IsValid()) {
		return false;
	}

	if (message.empty()) {
		return false;
	}

	ENetAddress address{};

	if (enet_address_set_host(
		&address,
		endpoint.ip.c_str()) != 0)
	{
		return false;
	}

	address.port = endpoint.port;

	ENetBuffer buffer{};

	buffer.data =
		const_cast<char*>(
			message.data()
			);

	buffer.dataLength =
		message.size();

	const int result =
		enet_socket_send(
			enetHost->socket,
			&address,
			&buffer,
			1
		);

	return result >= 0;
}