#include "StartCameraEvent.h"

#include <algorithm>

#include "../../CameraBase.h"

StartCameraEvent::StartCameraEvent(const Vector3& startPos, const Vector3& startAngle, float startFov, float frame) :
    CameraEventBase(),

    startPos(startPos), startRotation(Quaternion::FromEulerXZY(startAngle)), startFov(startFov),

    endPos(), endRotation(), endFov(0.0f),

    maxFrame((std::max)(frame, 1.0f)),
    currentFrame(0)
{
}

StartCameraEvent::StartCameraEvent(const CameraBase& camera, const Vector3& startLocalPos, const Vector3& startLocalAngle, float startLocalFov, float frame) :
    CameraEventBase(),

    startPos(camera.GetPos() + startLocalPos), startRotation(Quaternion::FromEulerXZY(startLocalAngle) * camera.GetRotation()), startFov(camera.GetFov() + startLocalFov),

    endPos(), endRotation(), endFov(0.0f),

    maxFrame((std::max)(frame, 1.0f)),
    currentFrame(0)
{
}

void StartCameraEvent::Start(CameraBase& camera)
{
    // �ʏ�Camera���{������ʒu��ۑ�
    endPos = camera.GetPos();
    endRotation = camera.GetRotation();
    endFov = camera.GetFov();

    // ��U�C�x���g�J�n�ʒu�ֈړ�
    camera.SetPos(startPos);
    camera.SetRotation(startRotation);
    camera.SetFov(startFov);

    currentFrame = 0;
}

void StartCameraEvent::Update(CameraBase& camera)
{
    currentFrame += camera.GetTimeScale();

    float rate = currentFrame / maxFrame;

    rate = std::clamp(rate, 0.0f, 1.0f);

    // �C�[�W���O
    float t = EaseInOut(rate);

    // ���W���
    Vector3 pos = startPos + (endPos - startPos) * t;

    // �p�x���
    Quaternion rotation = Quaternion::Slerp(startRotation, endRotation, t);

    // FOV���
    float fov = startFov + (endFov - startFov) * t;

    camera.SetPos(pos);
    camera.SetRotation(rotation);
    camera.SetFov(fov);
}

void StartCameraEvent::End(CameraBase& camera)
{
    camera.SetPos(endPos);
    camera.SetRotation(endRotation);
    camera.SetFov(endFov);
}

float StartCameraEvent::EaseInOut(float t)
{
    return t * t * (3.0f - 2.0f * t);
}