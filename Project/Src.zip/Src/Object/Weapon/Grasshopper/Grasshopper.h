#pragma once
#include "../WeaponBase.h"

#include "../../Common/AnimationController/CharacterAnimeTypeDefine.h"

class Grasshopper :
    public WeaponBase
{

public:
    Grasshopper(const Transform& ownerTrans,bool& isGrashpper);
    ~Grasshopper() override = default;

    void Load(void) override;

    int GetIdleAnimeID(void) const { return CHARACTER_ANIME::IDLE; }
    int GetAttackAnimeID(void) const { return CHARACTER_ANIME::SLASH_A1; }

    void OnCollision(COLLIDER_TAG ownTag, const ColliderBase& other, const CollisionResult& result)override;

    void OnEquip(void)override;

private:

    //���퐶��
    void Create(void);

    //���͕����擾
    Vector3 InputVec(void) const;

    void SubInit(void) override;
    void SubUpdate(void) override;
    void SubDraw(void) override;
    void SubRelease(void) override;

private:

    MATRIX weaponMatrix_;

    //�������̌X��
    MATRIX rotationMat;

    float tiltPitch_;   // ���݂̃s�b�`�p(���W�A��)
    float tiltRoll_;   // ���݂̃��[���p(���W�A��)

#pragma region �󂯎��Q��
    bool& isGrashpper;
#pragma endregion

};

