#include "Kogetsu.h"

#include "../../../pch.h"

#include "../../../Utility/Utility.h"

#include "../../Common/Collider/CapsuleCollider.h"

#include "../../Common/MeshSlicer/CutRequestQueue.h"

#include "../../Common/CuttableActor/CuttableActor.h"

Kogetsu::Kogetsu()
	:
	WeaponBase(Transform(), "Data/Parameter/Weapon/Kogetsu/")
{
}

Kogetsu::Kogetsu(const Transform& ownerTrans)
	:
	WeaponBase(ownerTrans, "Data/Parameter/Weapon/Kogetsu/"),
	attackColl(new CapsuleCollider(COLLIDER_TAG::Kogetsu,
		BladeDirHand()* BLADE_START, BladeDirHand()* (BLADE_START + BLADE_LENGTH), BLADE_RADIUS))
{
}

void Kogetsu::Load(void)
{
	trans.LoadModel("Weapon/Kogetsu");

	trans.SetLocalRotation(Quaternion::FromRotationZ(Deg2Rad(-90.0f)));

	SetJudgeFlg(false);

	// ���I�I�u�W�F�N�g�Ƃ��Ă̏�����L���ɂ���
	SetColliderMobility(COLLIDER_MOBILITY::Movable);

	attackColl->SetJudgeFlg(false);

	AddCollider(attackColl);

	// �����蔻��ɂ�鉟���o����L���ɂ���
	SetContactResponseEnabled(false);
	
}

void Kogetsu::On(void)
{
	attackColl->SetJudgeFlg(true);
	slash_.Reset();
	cutId_ = CutRequestQueue::IssueCutId();   // ��U�育�ƂɐV����ID
}

void Kogetsu::Off(void)
{
	attackColl->SetJudgeFlg(false);
}

void Kogetsu::OnCollision(COLLIDER_TAG ownTag, const ColliderBase& other, const CollisionResult& result)
{
	CuttableActor* target = dynamic_cast<CuttableActor*>(other.GetActor());
	if (target == nullptr) { return; }
	if (target->GetLastCutId() == cutId_) { return; }   // ���̈�U��Ő؂�������i�f�Ђ��j�͏���

	CutPlane plane;
	if (!slash_.GetPlane(plane)) { return; }            // �˂��E��~���͌�����
	CutRequestQueue::Push(target, plane, cutId_);
}

void Kogetsu::OnEquip(void)
{
	SetJudgeFlg(false);
	// ���I�I�u�W�F�N�g�Ƃ��Ă̏�����L���ɂ���
	SetColliderMobility(COLLIDER_MOBILITY::Movable);
}

void Kogetsu::SubInit(void)
{
	trans.scale = Vector3(GetParameter("Init", "scale"));
}

void Kogetsu::SubUpdate(void)
{
	const int frameIndex =
		MV1SearchFrame(
			ownerTrans.model,
			"mixamorig:RightHand"
		);

	if (frameIndex == -1)
	{
		return;
	}

	// �E��{�[���̃��[���h�s��
	MATRIX handMat =
		MV1GetFrameLocalWorldMatrix(
			ownerTrans.model,
			frameIndex
		);


	// ========================================
	// ��]�s����擾
	// ========================================

	const VECTOR handScale =
		MGetSize(handMat);

	MATRIX handRotationMat =
		MGetRotElem(handMat);

	// �X�P�[��������
	handRotationMat =
		MMult(
			handRotationMat,
			MGetScale(
				VGet(
					1.0f / handScale.x,
					1.0f / handScale.y,
					1.0f / handScale.z
				)
			)
		);


	// ========================================
	// ���W
	// ========================================

	const Vector3 handPos =
		Vector3(
			MGetTranslateElem(handMat)
		);

	// OFFSET�́u��]�����v�ŕϊ�����
	const Vector3 offset =
		Vector3(
			VTransform(
				OFFSET.ToVECTOR(),
				handRotationMat
			)
		);

	trans.pos =
		handPos +
		offset;


	// ========================================
	// ��]
	// ========================================

	trans.SetRotation(
		Quaternion::FromMatrix(
			handRotationMat
		)
	);

	// SubUpdate �̍Ō�ɒǉ�
	const Vector3 bladeDir = trans.VTrans(BladeDirHand());
	slash_.Update(trans.pos + bladeDir * BLADE_START, trans.pos + bladeDir * (BLADE_START + BLADE_LENGTH));

}

void Kogetsu::SubDraw(void)
{
//#ifdef _DEBUG
//	const Vector3 o = trans.pos;
//	DrawLine3D(o.ToVECTOR(), (o + trans.VTrans(Vector3::Xonly(1.0f)) * 100.0f).ToVECTOR(), GetColor(255, 0, 0));     // X = ��
//	DrawLine3D(o.ToVECTOR(), (o + trans.VTrans(Vector3::Yonly(1.0f)) * 100.0f).ToVECTOR(), GetColor(255, 255, 0));   // Y = ��
//	DrawLine3D(o.ToVECTOR(), (o + trans.VTrans(Vector3::Zonly(1.0f)) * 100.0f).ToVECTOR(), GetColor(255, 255, 255)); // Z = ��
//#endif
}

void Kogetsu::SubRelease(void)
{
}
