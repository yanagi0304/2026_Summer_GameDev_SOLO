#include "Shield.h"

Shield::Shield()
	: WeaponBase(Transform(), "Data/Parameter/Weapon/Shield/")
{
}

Shield::Shield(const Transform& ownerTrans)
	: WeaponBase(ownerTrans, "Data/Parameter/Weapon/Shield/")
{
}

void Shield::Load(void)
{
	trans.LoadModel("Weapon/Shield");

	SetJudgeFlg(false);

	// ���I�I�u�W�F�N�g�Ƃ��Ă̏�����L���ɂ���
	SetColliderMobility(COLLIDER_MOBILITY::Movable);
	SetContactResponseEnabled(false);
	SetIsDraw(false);

}

void Shield::SubInit(void)
{
	trans.scale = Vector3(GetParameter("Init", "scale"));
	SetDrawType(ACTOR_DRAW_TYPE::Alpha);
}

void Shield::SubUpdate(void)
{
	MV1SetOpacityRate(trans.model, 0.4f);

	const auto frameIndex =
		MV1SearchFrame(
			ownerTrans.model,
			"mixamorig:Spine2"
		);

	const Vector3 framePos =
		MV1GetFramePosition(
			ownerTrans.model,
			frameIndex
		);

	// �I�[�i�[�̑O����
	const Vector3 forward =
		ownerTrans.VTrans(
			Vector3(0.0f, 0.0f, 1.0f)
		);

	// ���W
	trans.pos =
		framePos +
		OFFSET +
		forward * 80.0f;

	// �I�[�i�[�Ɠ����p���ɂ���
	trans.SetRotation(ownerTrans.rotation);
}
