#include "CutMesh.h"

float CutMesh::SurfaceArea(bool excludeCap) const
{
	float total = 0.0f;

	for (const CutSubMesh& sub : subMeshes) {

		// �t�^�͌��̃��f���ɖ��������ʂȂ̂ŁA�������ɂ͊܂߂Ȃ�
		if (excludeCap && sub.materialIndex == -1) { continue; }

		// 3��1�O�p�`�B�[���͖�������
		for (size_t i = 0; i + 2 < sub.indices.size(); i += 3) {

			const Vector3& a = vertices[sub.indices[i]].pos;
			const Vector3& b = vertices[sub.indices[i + 1]].pos;
			const Vector3& c = vertices[sub.indices[i + 2]].pos;

			// �O�ς̒����͕��s�l�ӌ`�̖ʐςȂ̂ŁA�����ɂ���ƎO�p�`�̖ʐ�
			total += (b - a).Cross(c - a).Length() * 0.5f;
		}
	}

	return total;
}

void CutMesh::ToPositionsAndIndices(std::vector<Vector3>& outPositions, std::vector<unsigned int>& outIndices) const
{
	outPositions.clear();
	outIndices.clear();

	outPositions.reserve(vertices.size());
	for (const CutVertex& vertex : vertices) { outPositions.emplace_back(vertex.pos); }

	for (const CutSubMesh& sub : subMeshes) {
		outIndices.insert(outIndices.end(), sub.indices.begin(), sub.indices.end());
	}
}

CutMesh CutMesh::MakeBox(const Vector3& size)
{
	CutMesh mesh;
	CutSubMesh sub(0);

	const float half[3] = { size.x * 0.5f, size.y * 0.5f, size.z * 0.5f };

	// �ʓ���4���i-1 or +1�j
	const float cornerU[4] = { -1.0f,  1.0f, 1.0f, -1.0f };
	const float cornerV[4] = { -1.0f, -1.0f, 1.0f,  1.0f };

	// X,Y,Z�����Ƃ� +�� �� -�� �����
	for (int axis = 0; axis < 3; axis++) {

		const int uAxis = (axis + 1) % 3;
		const int vAxis = (axis + 2) % 3;

		for (int sign = -1; sign <= 1; sign += 2) {

			const unsigned int base = static_cast<unsigned int>(mesh.vertices.size());

			for (int c = 0; c < 4; c++) {
				float p[3] = {};
				float n[3] = {};

				p[axis] = half[axis] * static_cast<float>(sign);
				p[uAxis] = half[uAxis] * cornerU[c];
				p[vAxis] = half[vAxis] * cornerV[c];

				n[axis] = static_cast<float>(sign);

				CutVertex vertex;
				vertex.pos = Vector3(p[0], p[1], p[2]);
				vertex.normal = Vector3(n[0], n[1], n[2]);
				vertex.u = (cornerU[c] + 1.0f) * 0.5f;
				vertex.v = (cornerV[c] + 1.0f) * 0.5f;

				mesh.vertices.push_back(vertex);
			}

			// �������͊m�F�p�Ȃ̂Ō����ł͂Ȃ��i�ؒf�̌v�Z�ɂ͉e�����Ȃ��j
			if (sign > 0) {
				sub.indices.insert(sub.indices.end(), { base, base + 1, base + 2, base, base + 2, base + 3 });
			}
			else {
				sub.indices.insert(sub.indices.end(), { base, base + 2, base + 1, base, base + 3, base + 2 });
			}
		}
	}

	mesh.subMeshes.push_back(sub);

	return mesh;
}

void CutMesh::DrawWire(unsigned int color, const Vector3& offset) const
{
	for (const CutSubMesh& sub : subMeshes) {
		for (size_t i = 0; i + 2 < sub.indices.size(); i += 3) {

			const Vector3 p0 = vertices[sub.indices[i + 0]].pos + offset;
			const Vector3 p1 = vertices[sub.indices[i + 1]].pos + offset;
			const Vector3 p2 = vertices[sub.indices[i + 2]].pos + offset;

			DrawLine3D(p0.ToVECTOR(), p1.ToVECTOR(), color);
			DrawLine3D(p1.ToVECTOR(), p2.ToVECTOR(), color);
			DrawLine3D(p2.ToVECTOR(), p0.ToVECTOR(), color);
		}
	}
}
