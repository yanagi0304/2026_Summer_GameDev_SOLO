#pragma once

#include "ShaderBase.h"

#include "../../../Manager/Shader/ShaderTypeDefine.h"

class RimLightShader : public ShaderBase
{
public:
	RimLightShader(SHADER_VERTEX_TYPE vertexType = SHADER_VERTEX_TYPE::Frame8) :
		ShaderBase(),
		vertexType(vertexType)
	{
	}
	~RimLightShader()override = default;

	/// �V�F�[�_�[�̏�����
	void Init(void);

private:
	// ���_�^�C�v
	SHADER_VERTEX_TYPE vertexType;
};