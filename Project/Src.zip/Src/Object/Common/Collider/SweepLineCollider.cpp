#include "SweepLineCollider.h"

#include "../Collider/LineCollider.h"

SweepLineCollider::SweepLineCollider(const Vector3& pos)
	:currPos(pos),
	prevPos(currPos)
{
}

void SweepLineCollider::Load(void)
{
	AddCollider(new LineCollider(COLLIDER_TAG::DebugObject, currPos, prevPos));
}

void SweepLineCollider::SubUpdate(void)
{
	//�O��̍��W��O�t���[�����W�ɑ���
	prevPos = currPos;
}

void SweepLineCollider::SubDraw(void)
{
}
