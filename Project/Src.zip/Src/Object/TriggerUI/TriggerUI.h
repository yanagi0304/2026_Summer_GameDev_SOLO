#pragma once

#include "../Common/ActorBase/ActorBase.h"

#include "../Weapon/TriggerTypeDefine.h"

class TriggerUI : public ActorBase
{
public:

	const float SIZE_X = 499;
	const float SIZE_Y = 325;

	static constexpr float OFFSET = 20.0f;

public:

	TriggerUI(const int& mainCurrentIndex_, const int& subCurrentIndex_);
	~TriggerUI() = default;

	void Load();
	const char* TriggerToString(TriggerType trigger);
	void AddMain(TriggerType trigger) {mainTrig_.push_back(trigger); }
	void AddSub(TriggerType trigger) { subTrig_.push_back(trigger); }
	void Setweapon(const TriggerType trigger) { currentTrig_ = trigger; }
	std::vector<TriggerType> GetMainTrigger(void) const { return mainTrig_; }

private:

	std::vector<TriggerType> mainTrig_;
	std::vector<TriggerType> subTrig_;
	std::map< TriggerType, int> icon_;	//����A�C�R��
	TriggerType currentTrig_;

	//�摜�n���h��
	int triggerUI_;
	int select_;

	int x, y = 0;

	void SubUpdate()override;
	void SubDraw()override;
	void SubRelease()override;

	// ���݂̑I����Ԃ̎Q�Ɓi���C���g���K�[�j
	const int& mainCurrentIndex_;
	// ���݂̑I����Ԃ̎Q�Ɓi�T�u�g���K�[�j
	const int& subCurrentIndex_;

	ACTOR_DRAW_TYPE DefaultDrawType(void)const override { return ACTOR_DRAW_TYPE::Ui; }

};

