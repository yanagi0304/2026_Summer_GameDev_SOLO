#include "../Common/Vertex/VertexInputType.hlsli"

#define VERTEX_INPUT DX_VERTEX3DSHADER

#include "../Common/Vertex/VertexShader3DHeader.hlsli"

struct SkyBoxOutput
{
    float4 svPos : SV_POSITION;
    float3 direction : TEXCOORD0;
};

SkyBoxOutput main(VS_INPUT input)
{
    SkyBoxOutput output = (SkyBoxOutput) 0;

    // ��̐F�����߂邽�߂̕���
    output.direction = input.pos.xyz;

    // �J�����̉�]�̂ݓK�p
    float3 viewPos = mul(
        float4(input.pos.xyz, 0.0f),
        g_base.viewMatrix
    ).xyz;

    // �ˉe�ϊ�
    output.svPos = mul(
        float4(viewPos, 1.0f),
        g_base.projectionMatrix
    );

    // ��ɍŉ����̐[�x�ɔz�u
    output.svPos.z = output.svPos.w;

    return output;
}