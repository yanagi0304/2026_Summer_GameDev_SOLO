#pragma once

#include"../SceneBase.h"

#include "../../Object/Common/MeshSlicer/CutMesh.h"
#include "../../Object/Common/CuttableActor/CuttableActor.h"

class GameScene : public SceneBase
{
public:
	GameScene();
	~GameScene()override = default;

private:

#pragma region ��v�֐��Ē�`

	// �ǂݍ���
	void SubPostLoad(void)override;

	// ������
	void SubPostInit(void)override;

	// �X�V
	void SubPostUpdate(void)override;

	// UI�`��
	void SubUiDraw(void)override;

#pragma endregion

	bool UseSkyBox(void)const override { return true; }

	void CreateCamera(void)override;

	int CountMannequins(void) const;

	//���c�I�u�W�F
	ActorBase* operatorObject;

	//�}�l�L��
	ActorBase* mannequinManager;

	//debug
	CutMesh front;
	CutMesh back;

	CuttableActor* box_; 
	bool prevC_;


};